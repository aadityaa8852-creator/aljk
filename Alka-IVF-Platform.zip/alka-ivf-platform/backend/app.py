from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import uuid
from datetime import datetime, timedelta, timezone, date
from typing import Optional, Generator

from fastapi import FastAPI, Depends, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, EmailStr, ConfigDict
from sqlalchemy import create_engine, String, Boolean, Integer, DateTime, Text, ForeignKey, select, func, or_
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session

APP_NAME = "Alka IVF Platform API"
API_PREFIX = "/api/v1"
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./alka_ivf.db")
JWT_SECRET = os.getenv("JWT_SECRET", "dev-only-change-this-secret-before-deployment")
JWT_TTL_HOURS = int(os.getenv("JWT_TTL_HOURS", "8"))
FRONTEND_ORIGINS = os.getenv("FRONTEND_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
APP_ENV = os.getenv("APP_ENV", "development").lower()
if APP_ENV in ("production", "prod"):
    if len(JWT_SECRET) < 32 or "dev-only" in JWT_SECRET or "replace-this" in JWT_SECRET or "change-this" in JWT_SECRET:
        raise RuntimeError("Production must set JWT_SECRET to a unique random value of at least 32 characters")
    if DATABASE_URL.startswith("sqlite"):
        raise RuntimeError("Production must use a managed PostgreSQL database, not the local SQLite database")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(32), index=True)
    branch_id: Mapped[str] = mapped_column(String(64), default="alka-main")
    linked_patient_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso())

class Patient(Base):
    __tablename__ = "patients"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    uhid: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    patient_barcode: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    first_name: Mapped[str] = mapped_column(String(80))
    last_name: Mapped[str] = mapped_column(String(80), default="")
    phone: Mapped[str] = mapped_column(String(30), index=True)
    email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    treatment_unit_id: Mapped[str] = mapped_column(String(36), index=True)
    partner_patient_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    language: Mapped[str] = mapped_column(String(24), default="English")
    privacy_restricted: Mapped[bool] = mapped_column(Boolean, default=False)
    branch_id: Mapped[str] = mapped_column(String(64), default="alka-main")
    created_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso())

class Appointment(Base):
    __tablename__ = "appointments"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id: Mapped[str] = mapped_column(String(36), ForeignKey("patients.id"), index=True)
    doctor_name: Mapped[str] = mapped_column(String(120), default="First available specialist")
    appointment_at: Mapped[str] = mapped_column(String(40), index=True)
    visit_type: Mapped[str] = mapped_column(String(60), default="Initial consultation")
    mode: Mapped[str] = mapped_column(String(24), default="In person")
    status: Mapped[str] = mapped_column(String(24), default="scheduled", index=True)
    reason: Mapped[str] = mapped_column(String(500), default="")
    source: Mapped[str] = mapped_column(String(30), default="website")
    branch_id: Mapped[str] = mapped_column(String(64), default="alka-main")
    created_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso())
    created_by: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)

class Cycle(Base):
    __tablename__ = "cycles"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id: Mapped[str] = mapped_column(String(36), ForeignKey("patients.id"), index=True)
    treatment_unit_id: Mapped[str] = mapped_column(String(36), index=True)
    cycle_type: Mapped[str] = mapped_column(String(32), default="IVF")
    state: Mapped[str] = mapped_column(String(32), default="Planned", index=True)
    start_date: Mapped[str] = mapped_column(String(20), default=lambda: date.today().isoformat())
    protocol: Mapped[str] = mapped_column(String(100), default="To be selected by clinician")
    branch_id: Mapped[str] = mapped_column(String(64), default="alka-main")
    created_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso())
    created_by: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)

class CycleEvent(Base):
    __tablename__ = "cycle_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    cycle_id: Mapped[str] = mapped_column(String(36), ForeignKey("cycles.id"), index=True)
    from_state: Mapped[str] = mapped_column(String(32))
    to_state: Mapped[str] = mapped_column(String(32))
    notes: Mapped[str] = mapped_column(String(500), default="")
    occurred_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso())
    actor_id: Mapped[str] = mapped_column(String(36))

class LabMaterial(Base):
    __tablename__ = "lab_materials"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    material_code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    material_type: Mapped[str] = mapped_column(String(32))
    patient_id: Mapped[str] = mapped_column(String(36), ForeignKey("patients.id"), index=True)
    cycle_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="In lab")
    location: Mapped[str] = mapped_column(String(160), default="Embryology lab")
    consent_valid: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso())

class WitnessEvent(Base):
    __tablename__ = "witness_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    material_code: Mapped[str] = mapped_column(String(40), index=True)
    scanned_patient_barcode: Mapped[str] = mapped_column(String(40))
    first_user_id: Mapped[str] = mapped_column(String(36))
    second_user_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    result: Mapped[str] = mapped_column(String(24))
    reason: Mapped[str] = mapped_column(String(500), default="")
    created_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso())

class Consent(Base):
    __tablename__ = "consents"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id: Mapped[str] = mapped_column(String(36), ForeignKey("patients.id"), index=True)
    treatment_unit_id: Mapped[str] = mapped_column(String(36), index=True)
    consent_type: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    version: Mapped[str] = mapped_column(String(20), default="1.0")
    signed_at: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    withdrawn_at: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    created_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso())

class InventoryItem(Base):
    __tablename__ = "inventory_items"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(140))
    category: Mapped[str] = mapped_column(String(60))
    on_hand: Mapped[int] = mapped_column(Integer, default=0)
    reorder_level: Mapped[int] = mapped_column(Integer, default=0)
    unit: Mapped[str] = mapped_column(String(24), default="units")
    lot_number: Mapped[str] = mapped_column(String(80), default="")
    expires_on: Mapped[str] = mapped_column(String(20), default="")
    location: Mapped[str] = mapped_column(String(100), default="Main store")
    branch_id: Mapped[str] = mapped_column(String(64), default="alka-main")
    updated_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso())

class Invoice(Base):
    __tablename__ = "invoices"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    invoice_number: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    patient_id: Mapped[str] = mapped_column(String(36), ForeignKey("patients.id"), index=True)
    description: Mapped[str] = mapped_column(String(160))
    amount_paise: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(24), default="unpaid", index=True)
    due_date: Mapped[str] = mapped_column(String(20), default="")
    created_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso())

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    actor_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True, index=True)
    actor_role: Mapped[str] = mapped_column(String(32), default="anonymous")
    action: Mapped[str] = mapped_column(String(100), index=True)
    resource_type: Mapped[str] = mapped_column(String(80), index=True)
    resource_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True, index=True)
    details: Mapped[str] = mapped_column(Text, default="{}")
    ip_address: Mapped[str] = mapped_column(String(80), default="")
    created_at: Mapped[str] = mapped_column(String(40), default=lambda: now_iso(), index=True)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def new_id() -> str:
    return str(uuid.uuid4())

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return base64.b64encode(salt + digest).decode()

def verify_password(password: str, encoded: str) -> bool:
    try:
        raw = base64.b64decode(encoded.encode())
        salt, digest = raw[:16], raw[16:]
        check = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
        return hmac.compare_digest(digest, check)
    except Exception:
        return False

def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def create_token(user: User) -> str:
    header = b64url(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    payload = b64url(json.dumps({"sub": user.id, "role": user.role, "exp": int((datetime.now(timezone.utc) + timedelta(hours=JWT_TTL_HOURS)).timestamp())}, separators=(",", ":")).encode())
    signature = b64url(hmac.new(JWT_SECRET.encode(), f"{header}.{payload}".encode(), hashlib.sha256).digest())
    return f"{header}.{payload}.{signature}"

def decode_token(token: str) -> dict:
    try:
        head, payload, signature = token.split(".")
        expected = b64url(hmac.new(JWT_SECRET.encode(), f"{head}.{payload}".encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(signature, expected):
            raise ValueError("bad signature")
        data = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
        if int(data.get("exp", 0)) < int(datetime.now(timezone.utc).timestamp()):
            raise ValueError("expired")
        return data
    except Exception:
        raise HTTPException(status_code=401, detail="Session is invalid or expired")

def audit(db: Session, request: Request, actor: Optional[User], action: str, resource_type: str, resource_id: Optional[str] = None, details: Optional[dict] = None):
    forwarded = request.headers.get("x-forwarded-for", "")
    ip = forwarded.split(",")[0].strip() if forwarded else (request.client.host if request.client else "")
    db.add(AuditLog(actor_id=actor.id if actor else None, actor_role=actor.role if actor else "anonymous", action=action,
                    resource_type=resource_type, resource_id=resource_id, details=json.dumps(details or {}, ensure_ascii=False), ip_address=ip))

def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

security = HTTPBearer(auto_error=False)
def current_user(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security), db: Session = Depends(get_db)) -> User:
    if not credentials:
        raise HTTPException(status_code=401, detail="Sign in to continue")
    data = decode_token(credentials.credentials)
    user = db.get(User, data["sub"])
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="Account is unavailable")
    return user

def require_roles(*roles: str):
    def checker(user: User = Depends(current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status_code=403, detail="Your role does not have permission for this action")
        return user
    return checker

ROLE_LABELS = {
    "admin": "Hospital administrator", "doctor": "Reproductive specialist", "nurse": "Nurse",
    "receptionist": "Front desk", "embryologist": "Embryologist", "andrologist": "Andrologist",
    "accounts": "Accounts & billing", "compliance": "Compliance officer", "patient": "Patient"
}

class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=200)

class PatientIn(BaseModel):
    first_name: str = Field(min_length=1, max_length=80)
    last_name: str = Field(default="", max_length=80)
    phone: str = Field(min_length=7, max_length=30)
    email: Optional[EmailStr] = None
    language: str = Field(default="English", max_length=24)
    privacy_restricted: bool = False

class AppointmentIn(BaseModel):
    first_name: str = Field(min_length=1, max_length=80)
    last_name: str = Field(default="", max_length=80)
    phone: str = Field(min_length=7, max_length=30)
    email: Optional[EmailStr] = None
    appointment_at: str = Field(min_length=10, max_length=40)
    visit_type: str = Field(default="Initial consultation", max_length=60)
    mode: str = Field(default="In person", max_length=24)
    reason: str = Field(default="", max_length=500)
    branch_id: str = Field(default="alka-main", max_length=64)
    model_config = ConfigDict(extra="forbid")

class CycleIn(BaseModel):
    patient_id: str
    cycle_type: str = Field(default="IVF", max_length=32)
    start_date: str = Field(default_factory=lambda: date.today().isoformat())
    protocol: str = Field(default="To be selected by clinician", max_length=100)

class CycleEventIn(BaseModel):
    to_state: str
    notes: str = Field(default="", max_length=500)
    event_time: Optional[str] = None

class WitnessIn(BaseModel):
    material_code: str = Field(min_length=3, max_length=40)
    patient_barcode: str = Field(min_length=3, max_length=40)
    second_witness_email: EmailStr
    second_witness_password: str = Field(min_length=1, max_length=200)
    purpose: str = Field(default="Identity verification", max_length=120)

class CryoReleaseIn(BaseModel):
    material_code: str = Field(min_length=3, max_length=40)
    reason: str = Field(min_length=3, max_length=500)
    patient_barcode: str = Field(min_length=3, max_length=40)
    second_witness_email: EmailStr
    second_witness_password: str = Field(min_length=1, max_length=200)

class InventoryUpdateIn(BaseModel):
    change: int = Field(ge=-100000, le=100000)
    reason: str = Field(min_length=3, max_length=200)

class InvoiceIn(BaseModel):
    patient_id: str
    description: str = Field(min_length=3, max_length=160)
    amount_rupees: float = Field(gt=0, le=100000000)
    due_date: str = Field(default="", max_length=20)

class ConsentIn(BaseModel):
    patient_id: str
    consent_type: str = Field(min_length=3, max_length=80)
    status: str = Field(default="pending", pattern="^(pending|valid|conflict|withdrawn|expired)$")
    version: str = Field(default="1.0", max_length=20)

Base.metadata.create_all(bind=engine)

def seed_data():
    db = SessionLocal()
    try:
        if db.scalar(select(func.count()).select_from(User)):
            return
        # Entirely synthetic demonstration data; never use it as clinical data.
        patient_a = Patient(id=new_id(), uhid="ALK-DEMO-1001", patient_barcode="P-AL-1001", first_name="Aarav", last_name="Mehta", phone="+91 90000 10001", email="patient@alkaivf.demo", treatment_unit_id=new_id(), language="English")
        patient_b = Patient(id=new_id(), uhid="ALK-DEMO-1002", patient_barcode="P-AL-1002", first_name="Nisha", last_name="Mehta", phone="+91 90000 10002", email=None, treatment_unit_id=patient_a.treatment_unit_id, partner_patient_id=patient_a.id, language="Hindi")
        patient_a.partner_patient_id = patient_b.id
        db.add_all([patient_a, patient_b]); db.flush()
        demo_users = [
            ("Alka Admin", "admin@alkaivf.demo", "admin", None),
            ("Dr. Meera Sharma", "doctor@alkaivf.demo", "doctor", None),
            ("Kavita Rao", "nurse@alkaivf.demo", "nurse", None),
            ("Front Desk Demo", "reception@alkaivf.demo", "receptionist", None),
            ("Embryology Demo", "embryologist@alkaivf.demo", "embryologist", None),
            ("Accounts Demo", "accounts@alkaivf.demo", "accounts", None),
            ("Compliance Demo", "compliance@alkaivf.demo", "compliance", None),
            ("Aarav Mehta", "patient@alkaivf.demo", "patient", patient_a.id),
        ]
        for name, email, role, linked in demo_users:
            db.add(User(id=new_id(), name=name, email=email, password_hash=hash_password("AlkaDemo!2026"), role=role, linked_patient_id=linked))
        db.flush()
        today = date.today()
        for idx, (patient, days, h, visit_type, mode, status_value) in enumerate([
            (patient_a, 0, 10, "Monitoring scan", "In person", "confirmed"),
            (patient_b, 0, 11, "Follow-up consultation", "In person", "scheduled"),
            (patient_a, 1, 15, "Doctor consultation", "Video", "scheduled"),
            (patient_b, 2, 9, "Blood test review", "In person", "scheduled"),
        ]):
            dt = datetime.combine(today + timedelta(days=days), datetime.min.time()).replace(hour=h, minute=0, tzinfo=timezone.utc)
            db.add(Appointment(id=new_id(), patient_id=patient.id, doctor_name="Dr. Meera Sharma", appointment_at=dt.isoformat(), visit_type=visit_type, mode=mode, status=status_value, reason="Demonstration appointment", source="demo"))
        cycle = Cycle(id=new_id(), patient_id=patient_a.id, treatment_unit_id=patient_a.treatment_unit_id, cycle_type="IVF", state="Cultured", start_date=(today - timedelta(days=8)).isoformat(), protocol="Antagonist protocol")
        cycle_b = Cycle(id=new_id(), patient_id=patient_b.id, treatment_unit_id=patient_b.treatment_unit_id, cycle_type="FET", state="Planned", start_date=(today + timedelta(days=8)).isoformat(), protocol="To be confirmed by clinician")
        db.add_all([cycle, cycle_b]); db.flush()
        db.add_all([
            CycleEvent(id=new_id(), cycle_id=cycle.id, from_state="Planned", to_state="Stimulating", notes="Synthetic demonstration event", actor_id="system"),
            CycleEvent(id=new_id(), cycle_id=cycle.id, from_state="Stimulating", to_state="Retrieved", notes="Synthetic demonstration event", actor_id="system"),
            CycleEvent(id=new_id(), cycle_id=cycle.id, from_state="Retrieved", to_state="Fertilised", notes="Synthetic demonstration event", actor_id="system"),
            CycleEvent(id=new_id(), cycle_id=cycle.id, from_state="Fertilised", to_state="Cultured", notes="Synthetic demonstration event", actor_id="system"),
        ])
        db.add_all([
            Consent(id=new_id(), patient_id=patient_a.id, treatment_unit_id=patient_a.treatment_unit_id, consent_type="IVF treatment", status="valid", version="1.0", signed_at=now_iso()),
            Consent(id=new_id(), patient_id=patient_b.id, treatment_unit_id=patient_b.treatment_unit_id, consent_type="IVF treatment", status="valid", version="1.0", signed_at=now_iso()),
            Consent(id=new_id(), patient_id=patient_a.id, treatment_unit_id=patient_a.treatment_unit_id, consent_type="Embryo handling", status="valid", version="1.0", signed_at=now_iso()),
            Consent(id=new_id(), patient_id=patient_b.id, treatment_unit_id=patient_b.treatment_unit_id, consent_type="Embryo handling", status="valid", version="1.0", signed_at=now_iso()),
        ])
        db.add_all([
            LabMaterial(id=new_id(), material_code="OOC-2001", material_type="Oocyte batch", patient_id=patient_a.id, cycle_id=cycle.id, status="In lab", location="Embryology · Workbench 02", consent_valid=True),
            LabMaterial(id=new_id(), material_code="EMB-2002", material_type="Embryo", patient_id=patient_a.id, cycle_id=cycle.id, status="In culture", location="Incubator A · Dish 08", consent_valid=True),
            LabMaterial(id=new_id(), material_code="CRYO-3010", material_type="Frozen embryo", patient_id=patient_a.id, cycle_id=cycle.id, status="In storage", location="Tank 01 · Canister B · Cane 04", consent_valid=True),
            LabMaterial(id=new_id(), material_code="CRYO-4020", material_type="Frozen oocyte", patient_id=patient_b.id, cycle_id=None, status="In storage", location="Tank 02 · Canister A · Cane 01", consent_valid=False),
        ])
        db.add_all([
            InventoryItem(id=new_id(), name="Culture media", category="Embryology", on_hand=28, reorder_level=20, unit="vials", lot_number="CM-26-04", expires_on=(today + timedelta(days=120)).isoformat(), location="Lab cold storage"),
            InventoryItem(id=new_id(), name="Transfer catheters", category="Consumables", on_hand=9, reorder_level=12, unit="units", lot_number="TC-26-02", expires_on=(today + timedelta(days=210)).isoformat(), location="Procedure store"),
            InventoryItem(id=new_id(), name="Fertility injections", category="Pharmacy", on_hand=17, reorder_level=10, unit="packs", lot_number="FI-26-01", expires_on=(today + timedelta(days=35)).isoformat(), location="Pharmacy refrigerator"),
            InventoryItem(id=new_id(), name="Cryo gloves", category="Cryo lab", on_hand=3, reorder_level=8, unit="pairs", lot_number="CG-26-01", expires_on=(today + timedelta(days=320)).isoformat(), location="Cryo suite"),
        ])
        db.add_all([
            Invoice(id=new_id(), invoice_number="ALK-DEMO-INV-001", patient_id=patient_a.id, description="Consultation and diagnostic review", amount_paise=250000, status="paid", due_date=today.isoformat()),
            Invoice(id=new_id(), invoice_number="ALK-DEMO-INV-002", patient_id=patient_b.id, description="Monitoring and laboratory tests", amount_paise=685000, status="unpaid", due_date=(today + timedelta(days=7)).isoformat()),
        ])
        audit(db, type("R", (), {"headers": {}, "client": None})(), None, "demo_seed_created", "system", None, {"synthetic_data": True})
        db.commit()
    finally:
        db.close()

seed_data()

app = FastAPI(title=APP_NAME, version="1.0.0", description="Development API for the Alka IVF digital platform. Uses synthetic demo data.")
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in FRONTEND_ORIGINS if x.strip()], allow_credentials=True, allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"], allow_headers=["Authorization", "Content-Type"])

@app.get("/", tags=["system"])
def root():
    return {"name": APP_NAME, "api": API_PREFIX, "docs": "/docs", "environment": os.getenv("APP_ENV", "development")}

@app.get(f"{API_PREFIX}/health", tags=["system"])
def health(db: Session = Depends(get_db)):
    db.execute(select(1))
    return {"status": "ok", "service": "alka-ivf-api", "time": now_iso(), "database": "connected"}

@app.post(f"{API_PREFIX}/auth/login", tags=["authentication"])
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if not user or not user.is_active or not verify_password(body.password, user.password_hash):
        audit(db, request, None, "login_failed", "auth", None, {"email": body.email.lower()})
        db.commit()
        raise HTTPException(status_code=401, detail="Email or password is incorrect")
    audit(db, request, user, "login_succeeded", "user", user.id)
    db.commit()
    return {"access_token": create_token(user), "token_type": "bearer", "expires_in": JWT_TTL_HOURS * 3600,
            "user": {"id": user.id, "name": user.name, "email": user.email, "role": user.role, "role_label": ROLE_LABELS.get(user.role, user.role)}}

@app.get(f"{API_PREFIX}/auth/me", tags=["authentication"])
def me(user: User = Depends(current_user)):
    return {"id": user.id, "name": user.name, "email": user.email, "role": user.role, "role_label": ROLE_LABELS.get(user.role, user.role)}

@app.get(f"{API_PREFIX}/dashboard", tags=["dashboard"])
def dashboard(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "nurse", "receptionist", "embryologist", "accounts", "compliance"))):
    today_prefix = date.today().isoformat()
    result = {
        "patients": db.scalar(select(func.count()).select_from(Patient)) or 0,
        "appointments_today": db.scalar(select(func.count()).select_from(Appointment).where(Appointment.appointment_at.like(f"{today_prefix}%"), Appointment.status.in_(["scheduled", "confirmed"]))) or 0,
        "active_cycles": db.scalar(select(func.count()).select_from(Cycle).where(Cycle.state.not_in(["Closed", "Cancelled"]))) or 0,
        "lab_materials": db.scalar(select(func.count()).select_from(LabMaterial)) or 0,
        "unpaid_paise": db.scalar(select(func.coalesce(func.sum(Invoice.amount_paise), 0)).where(Invoice.status.in_(["unpaid", "partial"]))) or 0,
        "stock_alerts": db.scalar(select(func.count()).select_from(InventoryItem).where(InventoryItem.on_hand <= InventoryItem.reorder_level)) or 0,
        "role": user.role,
    }
    audit(db, request, user, "dashboard_viewed", "dashboard", None)
    db.commit()
    return result

@app.get(f"{API_PREFIX}/patients", tags=["patients"])
def list_patients(q: str = "", request: Request = None, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "nurse", "receptionist", "compliance"))):
    stmt = select(Patient).order_by(Patient.created_at.desc()).limit(100)
    if q.strip():
        like = f"%{q.strip()}%"
        stmt = select(Patient).where(or_(Patient.first_name.ilike(like), Patient.last_name.ilike(like), Patient.phone.ilike(like), Patient.uhid.ilike(like))).order_by(Patient.created_at.desc()).limit(100)
    rows = db.scalars(stmt).all()
    audit(db, request, user, "patient_list_read", "patient", None, {"count": len(rows), "searched": bool(q)})
    db.commit()
    return [{"id": p.id, "uhid": p.uhid, "patient_barcode": p.patient_barcode, "first_name": p.first_name, "last_name": p.last_name,
             "phone": p.phone, "email": p.email, "treatment_unit_id": p.treatment_unit_id, "partner_patient_id": p.partner_patient_id,
             "language": p.language, "privacy_restricted": p.privacy_restricted, "created_at": p.created_at} for p in rows if not p.privacy_restricted or user.role in ("admin", "doctor", "compliance")]

@app.post(f"{API_PREFIX}/patients", tags=["patients"])
def create_patient(body: PatientIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "receptionist"))):
    if db.scalar(select(Patient).where(Patient.phone == body.phone)):
        raise HTTPException(status_code=409, detail="A patient with this phone number already exists. Check for duplicates before registration.")
    p = Patient(id=new_id(), uhid=f"ALK-{secrets.token_hex(3).upper()}", patient_barcode=f"P-AL-{secrets.token_hex(3).upper()}", first_name=body.first_name.strip(), last_name=body.last_name.strip(), phone=body.phone.strip(), email=str(body.email).lower() if body.email else None, treatment_unit_id=new_id(), language=body.language, privacy_restricted=body.privacy_restricted)
    db.add(p); db.flush()
    audit(db, request, user, "patient_created", "patient", p.id, {"uhid": p.uhid})
    db.commit()
    return {"id": p.id, "uhid": p.uhid, "patient_barcode": p.patient_barcode, "first_name": p.first_name, "last_name": p.last_name, "phone": p.phone, "email": p.email, "treatment_unit_id": p.treatment_unit_id, "partner_patient_id": p.partner_patient_id, "language": p.language, "privacy_restricted": p.privacy_restricted, "created_at": p.created_at}

@app.post(f"{API_PREFIX}/appointments/public", tags=["appointments"])
def book_public_appointment(body: AppointmentIn, request: Request, db: Session = Depends(get_db)):
    if body.mode not in ("In person", "Video"):
        raise HTTPException(status_code=422, detail="Mode must be In person or Video")
    try:
        dt = datetime.fromisoformat(body.appointment_at.replace("Z", "+00:00"))
    except ValueError:
        raise HTTPException(status_code=422, detail="Appointment date/time is invalid")
    if dt < datetime.now(timezone.utc) - timedelta(minutes=5):
        raise HTTPException(status_code=422, detail="Please choose a future appointment time")
    # Lead-to-patient conversion keeps enquiry submissions attached to a record.
    patient = db.scalar(select(Patient).where(Patient.phone == body.phone))
    if not patient:
        patient = Patient(id=new_id(), uhid=f"ALK-{secrets.token_hex(3).upper()}", patient_barcode=f"P-AL-{secrets.token_hex(3).upper()}", first_name=body.first_name.strip(), last_name=body.last_name.strip(), phone=body.phone.strip(), email=str(body.email).lower() if body.email else None, treatment_unit_id=new_id(), branch_id=body.branch_id)
        db.add(patient); db.flush()
    elif patient.email is None and body.email:
        patient.email = str(body.email).lower()
    slot = Appointment(id=new_id(), patient_id=patient.id, doctor_name="First available specialist", appointment_at=dt.isoformat(), visit_type=body.visit_type, mode=body.mode, status="scheduled", reason=body.reason.strip(), source="website", branch_id=body.branch_id)
    db.add(slot); db.flush()
    audit(db, request, None, "public_appointment_booked", "appointment", slot.id, {"patient_id": patient.id, "source": "website"})
    db.commit()
    return {"appointment_id": slot.id, "status": slot.status, "appointment_at": slot.appointment_at, "visit_type": slot.visit_type,
            "mode": slot.mode, "message": "Your request has been received. The clinic team must confirm this appointment.", "reference": f"ALK-{slot.id[:8].upper()}"}

@app.get(f"{API_PREFIX}/appointments", tags=["appointments"])
def list_appointments(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "nurse", "receptionist", "compliance"))):
    rows = db.scalars(select(Appointment).order_by(Appointment.appointment_at.asc()).limit(200)).all()
    patients = {p.id: p for p in db.scalars(select(Patient)).all()}
    data = []
    for a in rows:
        p = patients.get(a.patient_id)
        if not p or (p.privacy_restricted and user.role not in ("admin", "doctor", "compliance")):
            continue
        data.append({"id": a.id, "patient_id": p.id, "patient_name": f"{p.first_name} {p.last_name}".strip(), "uhid": p.uhid, "phone": p.phone,
                     "doctor_name": a.doctor_name, "appointment_at": a.appointment_at, "visit_type": a.visit_type, "mode": a.mode, "status": a.status, "reason": a.reason, "source": a.source})
    audit(db, request, user, "appointment_list_read", "appointment", None, {"count": len(data)})
    db.commit()
    return data

@app.patch(f"{API_PREFIX}/appointments/{{appointment_id}}/status", tags=["appointments"])
def update_appointment_status(appointment_id: str, status_value: str, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "nurse", "receptionist"))):
    if status_value not in ("scheduled", "confirmed", "checked-in", "completed", "cancelled", "no-show"):
        raise HTTPException(status_code=422, detail="Unsupported appointment status")
    a = db.get(Appointment, appointment_id)
    if not a: raise HTTPException(status_code=404, detail="Appointment not found")
    old = a.status; a.status = status_value
    audit(db, request, user, "appointment_status_changed", "appointment", a.id, {"from": old, "to": status_value})
    db.commit()
    return {"id": a.id, "status": a.status}

@app.get(f"{API_PREFIX}/cycles", tags=["cycles"])
def list_cycles(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "nurse", "embryologist", "compliance"))):
    rows = db.scalars(select(Cycle).order_by(Cycle.created_at.desc())).all()
    patients = {p.id: p for p in db.scalars(select(Patient)).all()}
    data = []
    for c in rows:
        p = patients.get(c.patient_id)
        if p and (not p.privacy_restricted or user.role in ("admin", "doctor", "compliance")):
            data.append({"id": c.id, "patient_id": c.patient_id, "patient_name": f"{p.first_name} {p.last_name}".strip(), "uhid": p.uhid,
                         "cycle_type": c.cycle_type, "state": c.state, "start_date": c.start_date, "protocol": c.protocol, "created_at": c.created_at})
    audit(db, request, user, "cycle_list_read", "cycle", None, {"count": len(data)})
    db.commit()
    return data

@app.post(f"{API_PREFIX}/cycles", tags=["cycles"])
def create_cycle(body: CycleIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor"))):
    patient = db.get(Patient, body.patient_id)
    if not patient: raise HTTPException(status_code=404, detail="Patient not found")
    c = Cycle(id=new_id(), patient_id=patient.id, treatment_unit_id=patient.treatment_unit_id, cycle_type=body.cycle_type, state="Planned", start_date=body.start_date, protocol=body.protocol, created_by=user.id)
    db.add(c); db.flush()
    db.add(CycleEvent(id=new_id(), cycle_id=c.id, from_state="None", to_state="Planned", notes="Cycle created", actor_id=user.id))
    audit(db, request, user, "cycle_created", "cycle", c.id, {"cycle_type": c.cycle_type})
    db.commit()
    return {"id": c.id, "patient_id": c.patient_id, "cycle_type": c.cycle_type, "state": c.state, "start_date": c.start_date, "protocol": c.protocol}

def consent_gate_ready(db: Session, treatment_unit_id: str, consent_type: str) -> bool:
    members = db.scalars(select(Patient).where(Patient.treatment_unit_id == treatment_unit_id)).all()
    if not members:
        return False
    all_unit_consents = db.scalars(select(Consent).where(Consent.treatment_unit_id == treatment_unit_id)).all()
    if any(c.status == "conflict" for c in all_unit_consents):
        return False
    for member in members:
        member_consents = [c for c in all_unit_consents if c.patient_id == member.id and c.consent_type == consent_type]
        if not member_consents or not any(c.status == "valid" for c in member_consents):
            return False
        if any(c.status in ("withdrawn", "expired", "conflict") for c in member_consents):
            return False
    return True

ALLOWED_TRANSITIONS = {
    "Planned": {"Stimulating", "Cancelled"},
    "Stimulating": {"Triggered", "Cancelled"},
    "Triggered": {"Retrieved", "Cancelled"},
    "Retrieved": {"Fertilised", "Cancelled"},
    "Fertilised": {"Cultured", "Cancelled"},
    "Cultured": {"Transferred", "Cancelled", "Closed"},
    "Transferred": {"Awaiting result", "Cancelled"},
    "Awaiting result": {"Closed"},
    "Closed": set(), "Cancelled": set()
}
CRITICAL_STATES = {"Triggered", "Retrieved", "Fertilised", "Cultured", "Transferred"}

@app.post(f"{API_PREFIX}/cycles/{{cycle_id}}/events", tags=["cycles"])
def transition_cycle(cycle_id: str, body: CycleEventIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "nurse"))):
    c = db.get(Cycle, cycle_id)
    if not c: raise HTTPException(status_code=404, detail="Cycle not found")
    if body.to_state not in ALLOWED_TRANSITIONS.get(c.state, set()):
        raise HTTPException(status_code=409, detail=f"Invalid cycle transition: {c.state} → {body.to_state}")
    if body.to_state in CRITICAL_STATES and not consent_gate_ready(db, c.treatment_unit_id, "IVF treatment"):
        raise HTTPException(status_code=409, detail="Critical step blocked: each linked partner needs valid IVF treatment consent and no consent conflict may be present")
    if body.to_state == "Triggered" and not body.event_time:
        raise HTTPException(status_code=422, detail="Trigger event must include its exact date and time")
    old = c.state; c.state = body.to_state
    timestamp = body.event_time or now_iso()
    db.add(CycleEvent(id=new_id(), cycle_id=c.id, from_state=old, to_state=c.state, notes=body.notes, occurred_at=timestamp, actor_id=user.id))
    audit(db, request, user, "cycle_state_changed", "cycle", c.id, {"from": old, "to": c.state, "event_time": timestamp})
    db.commit()
    return {"id": c.id, "state": c.state, "event_time": timestamp}

@app.get(f"{API_PREFIX}/lab/materials", tags=["laboratory"])
def list_lab_materials(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "embryologist", "compliance"))):
    rows = db.scalars(select(LabMaterial).order_by(LabMaterial.created_at.desc())).all()
    patients = {p.id: p for p in db.scalars(select(Patient)).all()}
    result = []
    for m in rows:
        p = patients.get(m.patient_id)
        if not p or (p.privacy_restricted and user.role not in ("admin", "doctor", "compliance")): continue
        result.append({"id": m.id, "material_code": m.material_code, "material_type": m.material_type, "patient_id": m.patient_id, "patient_name": f"{p.first_name} {p.last_name}".strip(), "patient_barcode": p.patient_barcode, "uhid": p.uhid, "cycle_id": m.cycle_id, "status": m.status, "location": m.location, "consent_valid": m.consent_valid})
    audit(db, request, user, "lab_material_list_read", "lab_material", None, {"count": len(result)})
    db.commit()
    return result

def verify_second_witness(db: Session, current: User, email: str, password: str) -> User:
    second = db.scalar(select(User).where(User.email == email.lower(), User.is_active == True))
    if not second or second.id == current.id or second.role not in ("embryologist", "andrologist", "doctor", "compliance") or not verify_password(password, second.password_hash):
        raise HTTPException(status_code=403, detail="A different authorised staff member must authenticate as the second witness")
    return second

@app.post(f"{API_PREFIX}/lab/witness", tags=["laboratory"])
def witness_lab_step(body: WitnessIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "embryologist", "andrologist", "doctor"))):
    material = db.scalar(select(LabMaterial).where(LabMaterial.material_code == body.material_code))
    patient = db.scalar(select(Patient).where(Patient.patient_barcode == body.patient_barcode))
    reason = ""
    result = "blocked"
    second = None
    if not material or not patient:
        reason = "Unknown sample barcode or patient barcode"
    elif material.patient_id != patient.id:
        reason = "IDENTITY MISMATCH: sample does not belong to scanned patient"
    else:
        second = verify_second_witness(db, user, str(body.second_witness_email), body.second_witness_password)
        valid = material.consent_valid and consent_gate_ready(db, patient.treatment_unit_id, "IVF treatment") and consent_gate_ready(db, patient.treatment_unit_id, "Embryo handling")
        if not valid:
            reason = "Valid treatment/embryo-handling consent is missing, withdrawn, or conflicts with a linked partner's consent"
        else:
            result = "verified"
            reason = body.purpose
    ev = WitnessEvent(id=new_id(), material_code=body.material_code, scanned_patient_barcode=body.patient_barcode, first_user_id=user.id, second_user_id=second.id if second else None, result=result, reason=reason)
    db.add(ev)
    audit(db, request, user, "lab_witness_check", "lab_material", material.id if material else None, {"result": result, "reason": reason, "sample_code": body.material_code, "patient_barcode": body.patient_barcode, "second_witness_id": second.id if second else None})
    db.commit()
    if result != "verified":
        raise HTTPException(status_code=409, detail=f"Lab step blocked: {reason}")
    return {"result": result, "message": "Identity verified by two authorised staff members.", "material_code": material.material_code, "witness_event_id": ev.id}

@app.post(f"{API_PREFIX}/cryo/release", tags=["cryostorage"])
def release_cryo_material(body: CryoReleaseIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "embryologist", "compliance"))):
    material = db.scalar(select(LabMaterial).where(LabMaterial.material_code == body.material_code))
    patient = db.scalar(select(Patient).where(Patient.patient_barcode == body.patient_barcode))
    if not material or not patient or material.patient_id != patient.id:
        audit(db, request, user, "cryo_release_blocked_identity", "lab_material", material.id if material else None, {"sample_code": body.material_code})
        db.commit()
        raise HTTPException(status_code=409, detail="Release blocked: sample and patient identity do not match")
    if material.status != "In storage":
        audit(db, request, user, "cryo_release_blocked_status", "lab_material", material.id, {"status": material.status})
        db.commit()
        raise HTTPException(status_code=409, detail=f"Release blocked: sample status is '{material.status}', not 'In storage'")
    second = verify_second_witness(db, user, str(body.second_witness_email), body.second_witness_password)
    if not material.consent_valid or not consent_gate_ready(db, patient.treatment_unit_id, "IVF treatment") or not consent_gate_ready(db, patient.treatment_unit_id, "Embryo handling"):
        audit(db, request, user, "cryo_release_blocked_consent", "lab_material", material.id, {"reason": "consent missing or conflicting"})
        db.commit()
        raise HTTPException(status_code=409, detail="Release blocked: valid, non-conflicting consent is required")
    material.status = "Released - pending external handover" if "handover" in body.reason.lower() else "Released"
    db.add(WitnessEvent(id=new_id(), material_code=material.material_code, scanned_patient_barcode=patient.patient_barcode, first_user_id=user.id, second_user_id=second.id, result="release-authorised", reason=body.reason))
    audit(db, request, user, "cryo_release_authorised", "lab_material", material.id, {"reason": body.reason, "second_witness_id": second.id})
    db.commit()
    return {"result": "authorised", "material_code": material.material_code, "status": material.status}

@app.get(f"{API_PREFIX}/inventory", tags=["inventory"])
def list_inventory(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "accounts", "compliance", "embryologist"))):
    rows = db.scalars(select(InventoryItem).order_by(InventoryItem.name.asc())).all()
    audit(db, request, user, "inventory_list_read", "inventory", None, {"count": len(rows)})
    db.commit()
    return [{"id": i.id, "name": i.name, "category": i.category, "on_hand": i.on_hand, "reorder_level": i.reorder_level, "unit": i.unit, "lot_number": i.lot_number, "expires_on": i.expires_on, "location": i.location, "updated_at": i.updated_at, "low_stock": i.on_hand <= i.reorder_level} for i in rows]

@app.patch(f"{API_PREFIX}/inventory/{{item_id}}", tags=["inventory"])
def update_inventory(item_id: str, body: InventoryUpdateIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "accounts"))):
    item = db.get(InventoryItem, item_id)
    if not item: raise HTTPException(status_code=404, detail="Inventory item not found")
    new_qty = item.on_hand + body.change
    if new_qty < 0: raise HTTPException(status_code=409, detail="Stock cannot become negative")
    old_qty = item.on_hand; item.on_hand = new_qty; item.updated_at = now_iso()
    audit(db, request, user, "inventory_adjustment", "inventory_item", item.id, {"from": old_qty, "to": new_qty, "reason": body.reason})
    db.commit()
    return {"id": item.id, "on_hand": item.on_hand, "low_stock": item.on_hand <= item.reorder_level}

@app.get(f"{API_PREFIX}/invoices", tags=["billing"])
def list_invoices(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "accounts", "compliance"))):
    rows = db.scalars(select(Invoice).order_by(Invoice.created_at.desc())).all()
    patients = {p.id: p for p in db.scalars(select(Patient)).all()}
    data = [{"id": i.id, "invoice_number": i.invoice_number, "patient_id": i.patient_id, "patient_name": f"{patients[i.patient_id].first_name} {patients[i.patient_id].last_name}".strip() if i.patient_id in patients else "Unknown", "description": i.description, "amount_paise": i.amount_paise, "status": i.status, "due_date": i.due_date, "created_at": i.created_at} for i in rows]
    audit(db, request, user, "invoice_list_read", "invoice", None, {"count": len(data)})
    db.commit()
    return data

@app.get(f"{API_PREFIX}/billing/patient-options", tags=["billing"])
def billing_patient_options(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "accounts"))):
    rows = db.scalars(select(Patient).where(Patient.privacy_restricted == False).order_by(Patient.first_name.asc()).limit(300)).all()
    audit(db, request, user, "billing_patient_options_read", "patient", None, {"count": len(rows), "minimum_fields": True})
    db.commit()
    return [{"id": p.id, "name": f"{p.first_name} {p.last_name}".strip(), "uhid": p.uhid} for p in rows]

@app.post(f"{API_PREFIX}/invoices", tags=["billing"])
def create_invoice(body: InvoiceIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "accounts"))):
    patient = db.get(Patient, body.patient_id)
    if not patient: raise HTTPException(status_code=404, detail="Patient not found")
    invoice = Invoice(id=new_id(), invoice_number=f"ALK-{datetime.now().strftime('%y%m')}-{secrets.token_hex(3).upper()}", patient_id=patient.id, description=body.description, amount_paise=int(round(body.amount_rupees * 100)), status="unpaid", due_date=body.due_date)
    db.add(invoice); db.flush()
    audit(db, request, user, "invoice_created", "invoice", invoice.id, {"amount_paise": invoice.amount_paise})
    db.commit()
    return {"id": invoice.id, "invoice_number": invoice.invoice_number, "patient_id": invoice.patient_id, "description": invoice.description, "amount_paise": invoice.amount_paise, "status": invoice.status, "due_date": invoice.due_date}

@app.get(f"{API_PREFIX}/consents", tags=["consents"])
def list_consents(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "compliance", "embryologist"))):
    rows = db.scalars(select(Consent).order_by(Consent.created_at.desc())).all()
    patients = {p.id: p for p in db.scalars(select(Patient)).all()}
    data = [{"id": c.id, "patient_id": c.patient_id, "patient_name": f"{patients[c.patient_id].first_name} {patients[c.patient_id].last_name}".strip() if c.patient_id in patients else "Unknown", "treatment_unit_id": c.treatment_unit_id, "consent_type": c.consent_type, "status": c.status, "version": c.version, "signed_at": c.signed_at, "created_at": c.created_at} for c in rows]
    audit(db, request, user, "consent_list_read", "consent", None, {"count": len(data)})
    db.commit()
    return data

@app.post(f"{API_PREFIX}/consents", tags=["consents"])
def create_consent(body: ConsentIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "compliance"))):
    patient = db.get(Patient, body.patient_id)
    if not patient: raise HTTPException(status_code=404, detail="Patient not found")
    c = Consent(id=new_id(), patient_id=patient.id, treatment_unit_id=patient.treatment_unit_id, consent_type=body.consent_type, status=body.status, version=body.version, signed_at=now_iso() if body.status == "valid" else None)
    db.add(c); db.flush()
    audit(db, request, user, "consent_record_created", "consent", c.id, {"status": c.status, "type": c.consent_type})
    db.commit()
    return {"id": c.id, "patient_id": c.patient_id, "consent_type": c.consent_type, "status": c.status, "version": c.version, "signed_at": c.signed_at}

@app.patch(f"{API_PREFIX}/consents/{{consent_id}}/status", tags=["consents"])
def update_consent_status(consent_id: str, status_value: str, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "compliance"))):
    if status_value not in ("pending", "valid", "conflict", "withdrawn", "expired"):
        raise HTTPException(status_code=422, detail="Unsupported consent status")
    c = db.get(Consent, consent_id)
    if not c: raise HTTPException(status_code=404, detail="Consent not found")
    old = c.status; c.status = status_value
    c.signed_at = now_iso() if status_value == "valid" else c.signed_at
    c.withdrawn_at = now_iso() if status_value == "withdrawn" else c.withdrawn_at
    audit(db, request, user, "consent_status_changed", "consent", c.id, {"from": old, "to": status_value})
    db.commit()
    return {"id": c.id, "status": c.status}

@app.get(f"{API_PREFIX}/audit", tags=["audit"])
def list_audit(limit: int = 100, request: Request = None, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "compliance"))):
    limit = max(1, min(limit, 250))
    rows = db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit)).all()
    # Do not include raw IP in the dashboard response; it remains protected in the database.
    return [{"id": a.id, "actor_role": a.actor_role, "action": a.action, "resource_type": a.resource_type, "resource_id": a.resource_id, "details": a.details, "created_at": a.created_at} for a in rows]

@app.get(f"{API_PREFIX}/portal/me", tags=["patient portal"])
def portal_me(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("patient"))):
    patient = db.get(Patient, user.linked_patient_id) if user.linked_patient_id else None
    if not patient: raise HTTPException(status_code=404, detail="No patient record is linked to this account")
    audit(db, request, user, "patient_portal_viewed", "patient", patient.id)
    db.commit()
    return {"id": patient.id, "first_name": patient.first_name, "last_name": patient.last_name, "uhid": patient.uhid, "language": patient.language, "treatment_unit_id": patient.treatment_unit_id}

@app.get(f"{API_PREFIX}/portal/appointments", tags=["patient portal"])
def portal_appointments(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("patient"))):
    if not user.linked_patient_id: return []
    rows = db.scalars(select(Appointment).where(Appointment.patient_id == user.linked_patient_id).order_by(Appointment.appointment_at.asc())).all()
    audit(db, request, user, "patient_own_appointments_read", "appointment", None, {"count": len(rows)})
    db.commit()
    return [{"id": a.id, "appointment_at": a.appointment_at, "visit_type": a.visit_type, "mode": a.mode, "status": a.status, "doctor_name": a.doctor_name} for a in rows]

@app.get(f"{API_PREFIX}/portal/cycles", tags=["patient portal"])
def portal_cycles(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("patient"))):
    if not user.linked_patient_id: return []
    rows = db.scalars(select(Cycle).where(Cycle.patient_id == user.linked_patient_id).order_by(Cycle.created_at.desc())).all()
    audit(db, request, user, "patient_own_cycles_read", "cycle", None, {"count": len(rows)})
    db.commit()
    return [{"id": c.id, "cycle_type": c.cycle_type, "state": c.state, "start_date": c.start_date, "protocol": c.protocol} for c in rows]

@app.get(f"{API_PREFIX}/portal/invoices", tags=["patient portal"])
def portal_invoices(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("patient"))):
    if not user.linked_patient_id: return []
    rows = db.scalars(select(Invoice).where(Invoice.patient_id == user.linked_patient_id).order_by(Invoice.created_at.desc())).all()
    audit(db, request, user, "patient_own_invoices_read", "invoice", None, {"count": len(rows)})
    db.commit()
    return [{"id": i.id, "invoice_number": i.invoice_number, "description": i.description, "amount_paise": i.amount_paise, "status": i.status, "due_date": i.due_date} for i in rows]

@app.get(f"{API_PREFIX}/reports/summary", tags=["reports"])
def reports_summary(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "doctor", "accounts", "compliance"))):
    cycles = db.scalars(select(Cycle)).all()
    invoices = db.scalars(select(Invoice)).all()
    state_counts: dict[str, int] = {}
    for cycle in cycles: state_counts[cycle.state] = state_counts.get(cycle.state, 0) + 1
    data = {"cycle_states": state_counts, "invoice_count": len(invoices), "paid_paise": sum(i.amount_paise for i in invoices if i.status == "paid"), "unpaid_paise": sum(i.amount_paise for i in invoices if i.status in ("unpaid", "partial")), "note": "Demonstration summary only; success rates are intentionally not calculated from synthetic records."}
    audit(db, request, user, "report_summary_read", "report", None)
    db.commit()
    return data

@app.exception_handler(Exception)
async def internal_error_handler(request: Request, exc: Exception):
    # Avoid returning SQL, secrets, stack traces or patient data in API errors.
    import logging
    logging.getLogger("alka_ivf").exception("Unhandled server error at %s", request.url.path, exc_info=exc)
    from fastapi.responses import JSONResponse
    return JSONResponse(status_code=500, content={"detail": "An unexpected server error occurred", "code": "INTERNAL_ERROR"})
