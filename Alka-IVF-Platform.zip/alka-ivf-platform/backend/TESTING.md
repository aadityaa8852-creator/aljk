# Manual smoke tests

Start the API and use `http://localhost:8000/docs`, or run checks with `fastapi.testclient.TestClient` in an environment where the backend requirements are installed.

Critical scenarios to verify as the code evolves:

1. Patient role cannot read the staff patient registry (403).
2. Appointment requests reject malformed/past dates and accept a future request.
3. Cycle API rejects an invalid state transition (409), requires exact trigger time, and refuses a critical step if any linked partner's treatment consent is not valid.
4. Lab witness rejects a sample/patient barcode mismatch (409) and records a blocked witness attempt; success requires a different authorised witness to re-authenticate.
5. Cryostorage release rejects an identity mismatch and a sample with `consent_valid=False`, as well as missing/withdrawn/conflicting consent.
6. Accounts-only users can open invoices and minimum-field billing patient options, but cannot read the full clinical registry.
7. Audit views are only available to admin/compliance roles.

Demo material codes: `OOC-2001`, `EMB-2002`, `CRYO-3010`, `CRYO-4020`. Synthetic patient barcode examples: `P-AL-1001`, `P-AL-1002`.
